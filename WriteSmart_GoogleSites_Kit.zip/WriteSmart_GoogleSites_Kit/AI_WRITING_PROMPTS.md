# WriteSmart — Responsible AI Writing Prompts

Use these prompts with a permitted AI writing assistant. Students should follow their teacher's AI policy and never paste sensitive personal information.

## 1. Paragraph structure check
“Please review my paragraph for topic sentence, supporting details, and concluding sentence. Identify which sentence serves each role. Do not rewrite the paragraph. If a part is missing, ask me a guiding question.”

## 2. Grammar and clarity feedback
“Please identify up to five grammar or clarity issues in my draft. For each issue, quote only the short phrase needed, explain the problem in simple English, and offer one possible correction. Do not rewrite the whole draft. Keep my meaning and voice.”

## 3. Transition words
“Look at the relationships between my sentences. Suggest where a transition may help and give two possible transition words with a short explanation. Do not add new arguments or facts.”

## 4. Thesis and outline
“My topic is: [topic]. My current position is: [position]. Ask me questions that help me make the thesis specific and arguable. Then help me organize only the ideas I provide into an outline.”

## 5. Final revision reflection
“Here is my original sentence and the feedback I received: [paste]. Explain the feedback and ask me to decide whether to revise. Do not make the decision for me.”

## Student AI checklist
- Did I write my own ideas first?
- Did I verify each suggestion?
- Did I reject suggestions that changed my intended meaning?
- Did I avoid invented facts and sources?
- Can I explain the changes I accepted?
