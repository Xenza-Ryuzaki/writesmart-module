# WriteSmart — Google Forms Quiz Bank

**Suggested settings:** Quiz mode on; 1 point each; show correct answers and feedback after submission. Questions are in English to match the learning module.

1. **What is the main purpose of a topic sentence?**
   - A. To list all the examples
   - B. To state the paragraph’s main idea **(Correct)**
   - C. To introduce unrelated information
   - D. To repeat every sentence
   - Feedback: A topic sentence introduces the main idea and controlling opinion.

2. **Which sentence works best as a concluding sentence?**
   - A. First, students need a notebook.
   - B. Some students prefer blue pens.
   - C. Overall, good planning helps students write clearer essays. **(Correct)**
   - D. For example, my friend uses a laptop.
   - Feedback: A concluding sentence gives closure and reinforces the main point.

3. **Complete the sentence: “The app offers writing practice. ________, it gives instant feedback.”**
   - A. Furthermore **(Correct)**
   - B. However
   - C. In contrast
   - D. Although
   - Feedback: Furthermore adds another supporting point.

4. **Which is the strongest thesis for an argumentative essay?**
   - A. Social media exists today.
   - B. This essay is about social media.
   - C. Many teenagers have phones.
   - D. Schools should teach responsible social media use because it supports collaboration and digital literacy. **(Correct)**
   - Feedback: A strong thesis states a clear position and may preview reasons.

5. **How should a writer use AI feedback?**
   - A. Accept every suggestion without checking.
   - B. Review suggestions critically and keep control of the final text. **(Correct)**
   - C. Ask AI to invent sources and statistics.
   - D. Replace the writer’s ideas with a full AI essay.
   - Feedback: Check accuracy, relevance, and whether a suggestion preserves your meaning.

6. **Which peer-review comment is most helpful?**
   - A. Bad paragraph.
   - B. I do not like this topic.
   - C. Could you add an example to explain your second reason? **(Correct)**
   - D. Rewrite everything.
   - Feedback: Useful feedback is specific, respectful, and actionable.

**Suggested short-answer exit ticket (not auto-graded):**
- Three things I learned:
- Two things I improved in my writing:
- One goal for my next essay:
