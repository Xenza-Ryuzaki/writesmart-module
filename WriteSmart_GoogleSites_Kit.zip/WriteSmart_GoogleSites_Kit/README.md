# WriteSmart — Google Sites + Interactive Features Kit

## Isi paket
- `index.html`: prototype e-modul interaktif (HTML/CSS/JavaScript).
- `GOOGLE_SITES_SETUP_ID.md`: langkah untuk menempatkan modul di Google Sites.
- `GOOGLE_FORMS_QUIZ_BANK.md`: bank soal yang bisa dibuat ulang di Google Forms.
- `AI_WRITING_PROMPTS.md`: prompt AI yang membantu revisi tanpa mengambil alih tulisan siswa.

## Struktur produk
WriteSmart: Interactive Digital Module for High School Essay and Paragraph Building.
Target: Grade 10–11 / CEFR A2–B1.
Bab:
1. Foundations of Paragraph Structure
2. Thesis Statements & Essay Outlines
3. Cohesion, Transitions & AI-Assisted Drafting
4. Peer Review & Feedback Integration
5. Reflect and Publish: Final Essay Showcase

## Menjalankan prototype lokal
Buka `index.html` dengan browser modern. Kuis dan aktivitas dasar berjalan di sisi browser. Input tidak disimpan ke server; siswa perlu menyalin tulisan ke Google Docs untuk menyimpannya.

## Catatan integrasi
Google Sites tidak menjalankan sembarang file HTML/JavaScript lokal hanya dengan menempelkan kodenya. Untuk menyematkan seluruh prototype, hosting `index.html` di layanan web statis yang Anda kendalikan (misalnya GitHub Pages atau Netlify), lalu di Google Sites pilih Insert > Embed > By URL dan masukkan URL hasil hosting. Uji URL dan izin akses sebelum membagikannya kepada siswa.
