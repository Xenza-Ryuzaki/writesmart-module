# Panduan Integrasi WriteSmart ke Google Sites

## A. Buat situs utama
1. Buka https://sites.google.com/ dan buat Blank site.
2. Nama situs: **WriteSmart**.
3. Judul halaman utama: **Write Better. Think Clearly. WriteSmart.**
4. Buat halaman: Home, Chapter 1, Chapter 2, Chapter 3, Chapter 4, Chapter 5, Final Quiz, dan Teacher/Resources bila diperlukan.
5. Tambahkan deskripsi singkat, tujuan belajar, serta tombol navigasi ke tiap bab.

## B. Hosting prototype interaktif
Google Sites umumnya menyematkan konten web melalui URL. File lokal `index.html` perlu dipublikasikan ke hosting statis terlebih dahulu.

Pilihan hosting:
- GitHub Pages: buat repository baru, unggah `index.html` ke root, aktifkan Pages pada pengaturan repository, lalu tunggu URL publik tersedia.
- Netlify: deploy folder berisi `index.html` melalui alur deploy manual yang tersedia pada akun Anda.

Setelah URL publik aktif:
1. Buka Google Sites editor.
2. Pilih halaman tempat modul akan tampil.
3. Pilih **Insert > Embed > By URL**.
4. Tempel URL HTTPS dari hosting.
5. Klik Insert, atur ukuran embed agar nyaman dibaca, lalu preview desktop dan mobile.
6. Publish Google Sites dan uji lagi tautan modul dalam mode pengunjung.

Jangan memasukkan kredensial atau API key ke HTML publik. Prototype ini tidak memerlukan API key.

## C. Jika ingin tetap tanpa hosting
Bangun halaman dan konten langsung di Google Sites, lalu tambahkan:
- Google Docs untuk lembar kerja menulis dan outline.
- Google Forms untuk kuis/exit ticket.
- Video YouTube yang relevan.
- Link Gemini/Grammarly dengan prompt yang jelas dan aturan penggunaan AI.

Google Sites menjadi hub, sementara Forms/Docs menjadi aktivitas terpisah. Form perlu dibuat pada akun Anda sendiri; paket ini tidak membuat form live otomatis.

## D. Google Forms
1. Buka https://forms.google.com/ lalu buat Blank quiz.
2. Aktifkan Settings > Make this a quiz.
3. Masukkan pertanyaan dari `GOOGLE_FORMS_QUIZ_BANK.md`.
4. Tetapkan kunci jawaban dan poin (1 poin per pertanyaan).
5. Atur release grade/feedback sesuai kebutuhan kelas.
6. Salin URL form atau pilih embed, lalu masukkan ke Google Sites.

## E. Pemeriksaan sebelum dipakai siswa
- Uji semua menu dan tombol.
- Kerjakan kuis dengan jawaban benar dan salah.
- Pastikan form meminta data seminimal mungkin.
- Uji dengan ponsel dan koneksi internet yang lambat.
- Pastikan instruksi AI menegaskan siswa harus memeriksa saran dan mempertahankan ide sendiri.
- Periksa seluruh tautan eksternal, video, dan izin berbagi.

## F. Batasan prototype saat ini
- Input teks tidak otomatis disimpan dan tidak dikirim ke guru.
- Kuis pada HTML menghitung skor di browser, bukan menyimpan nilai ke Google Classroom.
- Belum ada login siswa, database, atau dashboard guru.
- Konten adalah draf produk berdasarkan worksheet yang berhasil ditelusuri; cocokkan kembali dengan dokumen lengkap dan kebijakan pengajar sebelum penerapan final.
